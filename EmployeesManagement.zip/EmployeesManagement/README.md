Project : gestion des employés et de paiament 
Chargés : Admin: SuperUser
charge RH: Gérer les paiaments 
Versions : "laravel/framework": "^9.2"
"php": "^8.0.2"
"bbotstrap": "5"
"xampp control panel": "3.3.0"
IDE : Visual studio code :"1.66.1"

Licence : Tout code sous dans ce projet est concrètement la
propriété de BluePen Labs © 2010 - 2017. Le code peut être
réutilisé, mais en aucun cas revendu.

