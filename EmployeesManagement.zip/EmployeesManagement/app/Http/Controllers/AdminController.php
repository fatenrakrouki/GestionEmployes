<?php

namespace App\Http\Controllers;
use App\Models\Admin;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    //Dashboard
    public function showAdminDashboard(){
        return view('index');
    }
    //Login
    public function showloginpage(){
        return view('login');
    }
     //Submit Login
     public function Submitlogin(Request $request){
         $request ->validate([
             'username' => 'required',
             'password' => 'required'
         ]); 
         $checkAdmin= Admin::where(['username'=> $request->username, 'password'=>$request->password])
         ->count();
         if($checkAdmin>0){
             session(['adminlogin',  true]);
             return redirect('admin');
         }
        }
         //Logout
    public function logout(){
        session()->forget('adminlogin');
        return view('admin/login');
    
    }
}
