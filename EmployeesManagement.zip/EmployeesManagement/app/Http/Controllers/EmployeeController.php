<?php

namespace App\Http\Controllers;
use App\Models\Contract;
use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data=Employee::orderBy('id','desc')->get();
        return view('Employee.index',['data'=>$data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data=Contract::orderBy('id','desc')->get();
        return view('employee.create',['contracts'=>$data]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'fullName'=>'required',
            'Householder'=>'required',
            'address'=>'required',
            'mobile'=>'required',
           
           
        ]);
         
        $data=new Employee();
        $data->contract_id=$request->contract;
        $data->cin=$request->cin;
        $data->fullName=$request->fullName;
        $data->Householder=$request->Householder;
        $data->address=$request->address;
        $data->mobile=$request->mobile;
        $data->nbrChild=$request->nbrChild;
        $data->save();

        return redirect('employee')->with('msg','Data has been submitted');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data=Employee::find($id);
        return view('employee.show',['data'=>$data]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $contracts=Contract::orderBy('id','desc')->get();
        $data=Employee::find($id);
        return view('employee.edit',['contracts'=>$contracts,'data'=>$data]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'fullName'=>'required',
            'Householder'=>'required',
            'address'=>'required',
            'mobile'=>'required',
           
           
        ]);
        $data=Employee::find($id);
        $data->contract_id=$request->contract;
        $data->cin=$request->cin;
        $data->fullName=$request->fullName;
        $data->Householder=$request->Householder;
        $data->address=$request->address;
        $data->mobile=$request->mobile;
        $data->nbrChild=$request->nbrChild;
        $data->save();

        return redirect('employee')->with('msg','Data has been updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Employee::where('id',$id)->delete();
        return redirect('employee');
    }
}
