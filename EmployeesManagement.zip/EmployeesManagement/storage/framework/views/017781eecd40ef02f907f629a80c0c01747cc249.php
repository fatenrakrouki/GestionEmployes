
<?php $__env->startSection('title','View Employee'); ?>
<?php $__env->startSection('content'); ?>
<div class="card mb-4 mt-4">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        View Employee
        <a href="<?php echo e(url('employee')); ?>" class="float-end btn btn-sm btn-success">View All</a>
    </div>
    <div class="card-body">

        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="text-danger"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(Session::has('msg')): ?>
        <p class="text-success"><?php echo e(session('msg')); ?></p>
        <?php endif; ?>
        <form method="post" action="<?php echo e(url('employee/'.$data->id)); ?>" enctype="multipart/form-data">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <table class="table table-bordered">
                <tr>
                    <th>Contrat</th>
                    <td>
                        <?php echo e($data->contract->type); ?>

                    </td>
                </tr>
                <tr>
                    <th>Full Name</th>
                    <td>
                        <?php echo e($data->fullName); ?>

                    </td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td>
                        <?php echo e($data->address); ?>

                    </td>
                </tr>
                <tr>
                    <th>Mobile</th>
                    <td>
                        <?php echo e($data->mobile); ?>

                    </td>
                </tr>
                <tr>
                    <th>Chef de famille </th>
                    <td>
                        <?php if($data->Householder==1): ?> oui <?php else: ?> non <?php endif; ?>
                        <br />
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EmployeesManagement\resources\views/employee/show.blade.php ENDPATH**/ ?>