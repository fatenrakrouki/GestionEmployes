
<?php $__env->startSection('title','View Contract'); ?>
<?php $__env->startSection('content'); ?>
<div class="card mb-4 mt-4">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        Contrat
        <a href="<?php echo e(url('Contract')); ?>" class="float-end btn btn-sm btn-success">View All</a>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                        <th>N°</th>
                        <th>Type</th>
                        <th>Sujet</th>
                        <th>Description</th>
                        <th>Durée</th>
                        <th>Date</th>
                        <th>Salaire brut</th>
                        <th>CNSS</th>
                        <th>FORPROLOS</th>
</tr>

               <tr>
                <td><?php echo e($data->id); ?></td>
                       <td><?php echo e($data->type); ?></td>
                       <td><?php echo e($data->subject); ?></td>
                       <td><?php echo e($data->description); ?></td>
                       <td><?php echo e($data->period); ?></td>
                       <td><?php echo e($data->startDate); ?></td>
                       <td><?php echo e($data->grossSalary); ?></td>
                       <td><?php echo e($data->cnssRate); ?></td>
                       <td><?php echo e($data->forprolosRate); ?></td>

                
            </tr>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EmployeesManagement\resources\views/Contract/show.blade.php ENDPATH**/ ?>