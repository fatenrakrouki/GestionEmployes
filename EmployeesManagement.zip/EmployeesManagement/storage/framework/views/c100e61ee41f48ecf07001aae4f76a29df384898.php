
<?php $__env->startSection('title','Salary Management'); ?>
<?php $__env->startSection('content'); ?>
<div class="card mb-4 mt-4">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        Paiment de salaire
        <a href="<?php echo e(url('employee')); ?>" class="float-end btn btn-sm btn-success">View All</a>
    </div>
    <div class="card-body">
    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
    
                        <div class="input-group">
                        <div class="col-md-12">
    <label for="type" class="form-label">N° CIN d'employé a payer </label>
  </div>
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EmployeesManagement\resources\views/Salary/index.blade.php ENDPATH**/ ?>