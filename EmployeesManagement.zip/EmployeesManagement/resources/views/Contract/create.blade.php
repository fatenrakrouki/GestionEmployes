@extends('layout')
@section('content')
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Ajouter un contrat</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    
    <div class="card-body">

    @if($errors->any())
            @foreach($errors->all() as $error)
                <p class="text-danger">{{$error}}</p>
            @endforeach
        @endif

        @if(Session::has('msg'))
        <p class="text-success">{{session('msg')}}</p>
        @endif
    <form class="row g-3" method="post" action="{{url('Contract')}}">
    @csrf
  <div class="col-md-4">
    <label for="type" class="form-label">Type</label>
    <input type="text" class="form-control" id="type" name="type">
  </div>
  <div class="col-md-4">
    <label for="sujet" class="form-label">Sujet</label>
    <input type="text" class="form-control" id="sujet" name="subject">
  </div>
  <div class="col-md-4">
    <label for="periode" class="form-label">Durée du contrat</label>
    <input type="text" class="form-control" id="periode" name="period">
  </div>
  <div class="col-md-4">
    <label for="salaire" class="form-label">Salaire Brut</label>
    <input type="text" class="form-control" id="salaire" name="grossSalary">
  </div>
  <div class="col-md-4">
    <label for="cnssRate" class="form-label">Taux de CNSS</label>
    <input type="number" class="form-control" id="cnssRate" name="cnssRate">
  </div>
  <div class="col-md-4">
    <label for="forprolosRate" class="form-label">Taux de FOPROLOS</label>
    <input type="number" class="form-control" id="forprolosRate" name="forprolosRate">
  </div>
  <div class="col-md-6">
    <label for="date" class="form-label">Date de début</label>
    <input type="date" class="form-control" id="date" name="startDate">
  </div>
  <div class="col-md-6">
    <label for="desc" class="form-label">Description</label>
    <input type="textarea" class="form-control" id="desc" name="description">
  </div>
  
  <div class="col-12 m-3">
    <button type="submit" class="btn btn-primary">Ajouter</button>
  </div>
</form>
    </div>
</div>

</div>
<!-- /.container-fluid -->

</div>
@endsection