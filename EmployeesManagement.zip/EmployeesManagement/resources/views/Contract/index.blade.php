@extends('layout')
@section('content')
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Tous les contrats</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
    <a href="{{url('Contract/create')}}" class="float-end btn btn-sm btn-success">Add New</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                  
                       <th>N°</th>
                        <th>Type</th>
                        <th>Sujet</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                    @if($data)
	                   @foreach($data as $d)
                       <td>{{$d->id}}</td>
                       <td>{{$d->type}}</td>
                       <td>{{$d->subject}}</td>
                       <td>{{$d->description}}</td>
                         <td>
                         <a href="{{url('Contract/'.$d->id)}}" class="btn btn-warning btn-sm">Show</a>
                         <a href="{{url('Contract/'.$d->id.'/edit')}}" class="btn btn-info btn-sm">Update</a>
                         <a onclick="return confirm('Are you sure to delete this data?')" href="{{url('Contract/'.$d->id.'/delete')}}" class="btn btn-danger btn-sm">Delete</a>
                      </td>
                    </tr>
                    @endforeach
                     @endif
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->

</div>
@endsection