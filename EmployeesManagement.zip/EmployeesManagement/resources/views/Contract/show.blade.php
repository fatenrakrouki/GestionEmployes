@extends('layout')
@section('title','View Contract')
@section('content')
<div class="card mb-4 mt-4">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        Contrat
        <a href="{{url('Contract')}}" class="float-end btn btn-sm btn-success">View All</a>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                        <th>N°</th>
                        <th>Type</th>
                        <th>Sujet</th>
                        <th>Description</th>
                        <th>Durée</th>
                        <th>Date</th>
                        <th>Salaire brut</th>
                        <th>CNSS</th>
                        <th>FORPROLOS</th>
</tr>

               <tr>
                <td>{{$data->id}}</td>
                       <td>{{$data->type}}</td>
                       <td>{{$data->subject}}</td>
                       <td>{{$data->description}}</td>
                       <td>{{$data->period}}</td>
                       <td>{{$data->startDate}}</td>
                       <td>{{$data->grossSalary}}</td>
                       <td>{{$data->cnssRate}}</td>
                       <td>{{$data->forprolosRate}}</td>

                
            </tr>
        </table>
    </div>
</div>
@endsection