<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ContractController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\SalaryController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('admin/login', [AdminController::class, 'showloginpage']);
Route::get('admin', [AdminController::class, 'showAdminDashboard']);
Route::post('admin/login', [AdminController::class, 'Submitlogin']);
Route::post('admin/logout', [AdminController::class, 'logout']);

// Contract Resource
Route::get('Contract/{id}/delete',[ContractController::class,'destroy']);
Route::resource('Contract',ContractController::class);

// Employee Resource
Route::get('employee/{id}/delete',[EmployeeController::class,'destroy']);
Route::resource('employee',EmployeeController::class);

// Salary 
Route::resource('salary', SalaryController::class);